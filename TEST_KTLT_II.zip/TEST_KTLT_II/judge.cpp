#include <bits/stdc++.h>
#include "study_in_pink2.h"
using namespace std;


void runTest(int s, int e){

		for (int i = s; i <= e; i++){
			try{
			string path = "C:\\Users\\MyPC\\OneDrive\\Desktop\\Test\\input\\input" + to_string(i) + ".txt";
			StudyPinkProgram* test = new StudyPinkProgram(path);
			test->run(false, i);
			delete test;}
			catch(const exception &ex){
				cout << "PROGRAM IS KILLED AT: input " << i << endl;
				cout << "BUG IS: " << ex.what() << endl;
			}
	}

	
		
		for (int i = s; i <= e; i++){
			try{
			string path_out = "C:\\Users\\MyPC\\OneDrive\\Desktop\\Test\\output\\output" + to_string(i) +".txt";
			string path_expect = "C:\\Users\\MyPC\\OneDrive\\Desktop\\Test\\expect\\expect" + to_string(i) + ".txt";
			ifstream file_out(path_out, ios::in);
			ifstream file_expect (path_expect, ios::in);
			stringstream out;
			stringstream expect; 
			out << file_out.rdbuf();
			expect << file_expect.rdbuf();
			if (out.str() != expect.str())
				cout << "Error at : " << i << endl;
		}
		catch(const exception &ex){
				cout << "PROGRAM IS KILLED AT: input " << i << endl;
				cout << "BUG IS: " << ex.what() << endl;
			}
		}
}

int main(){
	int s, e; 
	cout << "PLEASE ENTER START: "; cin >> s;
	cout << "PLEASE ENTER END: "; cin >> e;
	runTest(s,e);
	return EXIT_SUCCESS;
}